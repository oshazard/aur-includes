#ifndef UTILITY_H
#define UTILITY_H

#include <glib/gi18n.h>

extern GSettings *g_settings_var;

#endif
